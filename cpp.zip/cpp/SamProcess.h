#include <iostream>
#include <string>
#include <algorithm>
#include <stdlib.h>
#include <sstream>
#include <thread>
#include <ctime>
#include "SamParser.h"
#include "AlignmentRecord.h"
ALIGNRECORDS records;
std::vector<std::string> qNames;
void ajustRecords(const std::vector<std::string> & qNames,int begin, int end, int readLength, int minLength);
void ajustRecord(AlignmentRecord &record1, AlignmentRecord &record2, int readLength, int minLength);
std::vector<std::string> getQNames(void);